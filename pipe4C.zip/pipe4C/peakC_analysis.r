install.packages("isotone")
install.packages("caTools")
install.packages("fansi")
install.packages("pkgload")
install.packages("BiocManager")
BiocManager::install("GenomicRanges")
install.packages("devtools")
library(devtools)
devtools::install_github('deWitLab/peakC', force = TRUE)
#install.packages("peakC")
#library(peakC)

pipe4CFunctionsFile <- "/media/fatemeh/Elements1/4C/pipe4C/functions.R"
source(pipe4CFunctionsFile)

### This param should be adjusted in function.R --> line 1571
alphaFDR = "0.1"
gene = "TBP"

FileDirectory <- paste0("/media/fatemeh/Elements1/4C/pipe4C/outF/RDS")
rdsFiles <- dir(path=FileDirectory, full=TRUE)

resPeakC <- doPeakC(rdsFiles = rdsFiles)
plot_C(resPeakC,y.max=150)

resPeaks <- getPeakCPeaks(resPeakC=resPeakC)
peaksFile <- paste0(FileDirectory, gene, "_alphaFDR_",alphaFDR, "_qwr_1.bed")
exportPeakCPeaks(resPeakC=resPeakC,bedFile=peaksFile,name=paste0(gene,"_alphaFDR_", alphaFDR, "_qwr_1.bed"))

### export the bedgraph file to be visualized in pyGenomeTracks
bed_file <- paste0(FileDirectory, "/", gene, ".bedgraph")

bedDF <- as.data.frame(resPeakC$dbR)[,1:2]
bedDF$new <- resPeakC$dbR$pos +1
bedDF$chrom <- resPeakC$vpChr
bed <- data.frame()
bed <- bedDF[c(4,1,3,2)]
names(bed)[1] <- "chrom"
names(bed)[2] <- "chromStart"
names(bed)[3] <- "chromEnd"
names(bed)[4] <- "dataValue"
write.table(bed,file=bed_file,sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE,append=TRUE)
#plot(resPeakC$dbR[,1], resPeakC$dbR[,2], type='h', ylim=c(0,150), xlab="chromosomal position", ylab="4C signal")

